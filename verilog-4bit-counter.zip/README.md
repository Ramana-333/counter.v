# 4-bit Synchronous Counter in Verilog

## 📦 Description
Simple 4-bit synchronous up-counter with active-high reset, designed in Verilog.

## 🛠 Files
- `counter.v` : RTL code of the counter
- `counter_tb.v` : Testbench to simulate the counter

## ⚙️ How to simulate (using Icarus Verilog + GTKWave)
```bash
iverilog -o counter_tb counter.v counter_tb.v
vvp counter_tb
gtkwave counter.vcd
```

## 📊 Simulation result
The waveform should show the counter incrementing on each clock edge, and resetting to zero when reset is high.
